package ecsite.Service;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.service.ItemSearchService;

class ItemSearchServiceTest {

	ItemsStub stub = new ItemsStub();
	ItemsStubException stubE = new ItemsStubException();

	@Test
	void testNo1() {
		/*
		 * コンストラクタのテスト
		 * 正しく動作するかの確認
		 */
		ItemSearchService service = new ItemSearchService(stub);
		List<ItemsDTO> itemList = new ArrayList<>();

		try {
			itemList = service.itemSearch("", "0");
		}catch(SQLException | NumberFormatException | ClassNotFoundException | NullPointerException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(16, itemList.size());
	}

	@Test
	void testNo2() {
		/*
		 * コンストラクタのテスト
		 * NullPointerExceptionがスローされるかを確認
		 */

		ItemSearchService service = new ItemSearchService(null);

		assertThrows(NullPointerException.class, () -> service.itemSearch("", "0"));
	}

	@Test
	void testNo3() {
		/*
		 * 検索の条件分岐のテスト
		 * 全件検索が行われるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);
		List<ItemsDTO> itemList = new ArrayList<>();

		try {
			itemList = service.itemSearch("", "0");
		}catch(SQLException | NumberFormatException | ClassNotFoundException | NullPointerException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(16, itemList.size());
	}

	@Test
	void testNo4() {
		/*
		 * 検索の条件分岐のテスト
		 * キーワード検索が行われるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);
		List<ItemsDTO> itemList = new ArrayList<>();

		try {
			itemList = service.itemSearch("A", "0");
		}catch(SQLException | NumberFormatException | ClassNotFoundException | NullPointerException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(2, itemList.size());
	}

	@Test
	void testNo5() {
		/*
		 * 検索の条件分岐のテスト
		 * カテゴリー検索が行われるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);
		List<ItemsDTO> itemList = new ArrayList<>();

		try {
			itemList = service.itemSearch("", "1");
		}catch(SQLException | NumberFormatException | ClassNotFoundException | NullPointerException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(9, itemList.size());
	}

	@Test
	void testNo6() {
		/*
		 * 検索の条件分岐のテスト
		 * AND検索が行われるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);
		List<ItemsDTO> itemList = new ArrayList<>();

		try {
			itemList = service.itemSearch("A", "1");
		}catch(SQLException | NumberFormatException | ClassNotFoundException | NullPointerException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(1, itemList.size());
	}

	@Test
	void testNo7() {
		/*
		 * 入力値判定のテスト
		 * NullPointerExceptionがスローされるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);

		assertThrows(NullPointerException.class, () -> service.itemSearch(null, "0"));
	}

	@Test
	void testNo8() {
		/*
		 * 入力値判定のテスト
		 * NullPointerExceptionがスローされるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);

		assertThrows(NullPointerException.class, () -> service.itemSearch("", null));
	}

	@Test
	void testNo9() {
		/*
		 * 入力値判定のテスト
		 * NumberFormatExceptionがスローされるかの確認
		 */

		ItemSearchService service = new ItemSearchService(stub);

		assertThrows(NumberFormatException.class, () -> service.itemSearch("", "a"));
	}

	@Test
	void testNo10() {
		/*
		 * 検索方法別のException動作テスト
		 * SQLExceptionがスローされるかの確認
		 */
		ItemSearchService service = new ItemSearchService(stubE);

		assertThrows(SQLException.class, () -> service.itemSearch("", "0"));
	}

	@Test
	void testNo11() {
		/*
		 * 検索方法別のException動作テスト
		 * SQLExceptionがスローされるかの確認
		 */
		ItemSearchService service = new ItemSearchService(stubE);

		assertThrows(SQLException.class, () -> service.itemSearch("A", "0"));
	}

	@Test
	void testNo12() {
		/*
		 * 検索方法別のException動作テスト
		 * SQLExceptionがスローされるかの確認
		 */
		ItemSearchService service = new ItemSearchService(stubE);

		assertThrows(SQLException.class, () -> service.itemSearch("", "1"));
	}

	@Test
	void testNo13() {
		/*
		 * 検索方法別のException動作テスト
		 * SQLExceptionがスローされるかの確認
		 */
		ItemSearchService service = new ItemSearchService(stubE);

		assertThrows(SQLException.class, () -> service.itemSearch("A", "1"));
	}
}
