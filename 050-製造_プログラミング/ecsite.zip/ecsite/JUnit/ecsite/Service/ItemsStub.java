package ecsite.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;

public class ItemsStub implements IItemsDAO<ItemsDTO> {

	List<ItemsDTO> allList = null;
	List<ItemsDTO> keywordList = null;
	List<ItemsDTO> categoryList = null;
	List<ItemsDTO> bothList = null;

	String[] allName = {"麦わら帽子",
						"ストローハット",
						"ストローハット　PART2",
						"野球帽",
						"ニットキャップ",
						"ハンチング帽",
						"ターバン",
						"ベレー帽",
						"マジック用ハット",
						"鞄A",
						"鞄B",
						"鞄E",
						"鞄H",
						"鞄F",
						"鞄C",
						"鞄D"
						};
	String[] keywordName = {"ストローハット　PART2",
							"鞄A"
							};
	String[] categoryName = {"麦わら帽子",
							 "ストローハット",
							 "ストローハット　PART2",
							 "野球帽",
							 "ニットキャップ",
							 "ハンチング帽",
							 "ターバン",
							 "ベレー帽",
							 "マジック用ハット"
							 };
	String[] bothName = {"ストローハット　PART2"
						};

	public ItemsStub() {
		allList = new ArrayList<>();
		keywordList = new ArrayList<>();
		categoryList = new ArrayList<>();
		bothList = new ArrayList<>();

		for(int i=0;i<allName.length;i++) {
			ItemsDTO dto = new ItemsDTO();
			dto.setItemName(allName[i]);
			allList.add(dto);
		}

		for(int i=0;i<keywordName.length;i++) {
			ItemsDTO dto = new ItemsDTO();
			dto.setItemName(keywordName[i]);
			keywordList.add(dto);
		}

		for(int i=0;i<categoryName.length;i++) {
			ItemsDTO dto = new ItemsDTO();
			dto.setItemName(categoryName[i]);
			categoryList.add(dto);
		}

		for(int i=0;i<bothName.length;i++) {
			ItemsDTO dto = new ItemsDTO();
			dto.setItemName(bothName[i]);
			bothList.add(dto);
		}
	}

	public List<ItemsDTO> findAll(Connection con) throws SQLException {
		return allList;
	}

	public List<ItemsDTO> findByKeyword(Connection con, String keyword) throws SQLException {
		return keywordList;
	}

	public List<ItemsDTO> findByCategoryId(Connection con, int categoryId) throws SQLException {
		return categoryList;
	}

	public List<ItemsDTO> findByBoth(Connection con, String keyword, int categoryId) throws SQLException {
		return bothList;
	}

	public ItemsDTO findByItemId(Connection con, int itemId) throws SQLException {
		ItemsDTO dto = new ItemsDTO();

		dto.setItemName("麦わら帽子");

		return dto;
	}
}
