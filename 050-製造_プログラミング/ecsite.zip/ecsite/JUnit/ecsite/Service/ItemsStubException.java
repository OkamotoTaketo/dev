package ecsite.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;

public class ItemsStubException implements IItemsDAO<ItemsDTO> {

	public List<ItemsDTO> findAll(Connection con) throws SQLException {
		throw new SQLException();
	}

	public List<ItemsDTO> findByKeyword(Connection con, String keyword) throws SQLException {
		throw new SQLException();
	}

	public List<ItemsDTO> findByCategoryId(Connection con, int categoryId) throws SQLException {
		throw new SQLException();
	}

	public List<ItemsDTO> findByBoth(Connection con, String keyword, int categoryId) throws SQLException {
		throw new SQLException();
	}

	public ItemsDTO findByItemId(Connection con, int itemId) throws SQLException {
		throw new SQLException();
	}
}
