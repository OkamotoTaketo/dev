package ecsite.dao;

import java.util.ArrayList;
import java.util.List;

import com.bh.ecsite.dto.CategoriesDTO;
import com.bh.ecsite.dto.ItemsDTO;

public class DAOTestData {

	private List<ItemsDTO> allData = null;
	private List<ItemsDTO> keywordData = null;
	private List<ItemsDTO> categoryData1 = null;
	private List<ItemsDTO> categoryData2 = null;

	ItemsDTO dto = null;

	public DAOTestData() {
		allData = new ArrayList<>();
		keywordData = new ArrayList<>();
		categoryData1 = new ArrayList<>();
		categoryData2 = new ArrayList<>();

//		全件検索データ作成
		dto = new ItemsDTO();
		dto.setItemId(1);
		dto.setItemName("麦わら帽子");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("黄色");
		dto.setPrice(4980);
		dto.setStock(12);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(2);
		dto.setItemName("ストローハット");
		dto.setManufacturer("(株)ストローハットジャパン");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("茶色");
		dto.setPrice(3480);
		dto.setStock(15);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(4);
		dto.setItemName("ストローハット PART2");
		dto.setManufacturer("(株)ストローハットジャパン");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("青色");
		dto.setPrice(4480);
		dto.setStock(6);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(5);
		dto.setItemName("野球帽");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("緑色");
		dto.setPrice(2500);
		dto.setStock(17);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(6);
		dto.setItemName("ニットキャップ");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("紺色");
		dto.setPrice(1800);
		dto.setStock(9);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(7);
		dto.setItemName("ハンチング帽");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("黄色");
		dto.setPrice(1980);
		dto.setStock(20);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(9);
		dto.setItemName("ターバン");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("赤色");
		dto.setPrice(4580);
		dto.setStock(1);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(10);
		dto.setItemName("ベレー帽");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("青色");
		dto.setPrice(3200);
		dto.setStock(8);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(11);
		dto.setItemName("マジック用ハット");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("緑色");
		dto.setPrice(650);
		dto.setStock(17);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(12);
		dto.setItemName("鞄A");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("青色");
		dto.setPrice(1980);
		dto.setStock(18);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(13);
		dto.setItemName("鞄B");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("緑色");
		dto.setPrice(4980);
		dto.setStock(15);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(14);
		dto.setItemName("鞄E");
		dto.setManufacturer("(株)鞄");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("紺色");
		dto.setPrice(2200);
		dto.setStock(3);
		dto.setRecommended(false);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(16);
		dto.setItemName("鞄H");
		dto.setManufacturer("日本鞄製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("茶色");
		dto.setPrice(780);
		dto.setStock(17);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(17);
		dto.setItemName("鞄F");
		dto.setManufacturer("(株)鞄");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("赤色");
		dto.setPrice(2500);
		dto.setStock(9);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(18);
		dto.setItemName("鞄C");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("青色");
		dto.setPrice(1800);
		dto.setStock(20);
		dto.setRecommended(true);
		allData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(19);
		dto.setItemName("鞄D");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("緑色");
		dto.setPrice(1980);
		dto.setStock(2);
		dto.setRecommended(false);
		allData.add(dto);

//		キーワードデータの作成
		dto = new ItemsDTO();
		dto.setItemId(4);
		dto.setItemName("ストローハット PART2");
		dto.setManufacturer("(株)ストローハットジャパン");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("青色");
		dto.setPrice(4480);
		dto.setStock(6);
		dto.setRecommended(false);
		keywordData.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(12);
		dto.setItemName("鞄A");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("青色");
		dto.setPrice(1980);
		dto.setStock(18);
		dto.setRecommended(true);
		keywordData.add(dto);

//		カテゴリー(1)データの作成
		dto = new ItemsDTO();
		dto.setItemId(1);
		dto.setItemName("麦わら帽子");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("黄色");
		dto.setPrice(4980);
		dto.setStock(12);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(2);
		dto.setItemName("ストローハット");
		dto.setManufacturer("(株)ストローハットジャパン");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("茶色");
		dto.setPrice(3480);
		dto.setStock(15);
		dto.setRecommended(true);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(4);
		dto.setItemName("ストローハット PART2");
		dto.setManufacturer("(株)ストローハットジャパン");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("青色");
		dto.setPrice(4480);
		dto.setStock(6);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(5);
		dto.setItemName("野球帽");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("緑色");
		dto.setPrice(2500);
		dto.setStock(17);
		dto.setRecommended(true);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(6);
		dto.setItemName("ニットキャップ");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("紺色");
		dto.setPrice(1800);
		dto.setStock(9);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(7);
		dto.setItemName("ハンチング帽");
		dto.setManufacturer("日本帽子製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("黄色");
		dto.setPrice(1980);
		dto.setStock(20);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(9);
		dto.setItemName("ターバン");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("赤色");
		dto.setPrice(4580);
		dto.setStock(1);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(10);
		dto.setItemName("ベレー帽");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("青色");
		dto.setPrice(3200);
		dto.setStock(8);
		dto.setRecommended(false);
		categoryData1.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(11);
		dto.setItemName("マジック用ハット");
		dto.setManufacturer("東京帽子店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("帽子");
		dto.setColor("緑色");
		dto.setPrice(650);
		dto.setStock(17);
		dto.setRecommended(true);
		categoryData1.add(dto);

//		カテゴリーデータ(2)の作成
		dto = new ItemsDTO();
		dto.setItemId(12);
		dto.setItemName("鞄A");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("青色");
		dto.setPrice(1980);
		dto.setStock(18);
		dto.setRecommended(true);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(13);
		dto.setItemName("鞄B");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("緑色");
		dto.setPrice(4980);
		dto.setStock(15);
		dto.setRecommended(false);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(14);
		dto.setItemName("鞄E");
		dto.setManufacturer("(株)鞄");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("紺色");
		dto.setPrice(2200);
		dto.setStock(3);
		dto.setRecommended(false);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(16);
		dto.setItemName("鞄H");
		dto.setManufacturer("日本鞄製造");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("茶色");
		dto.setPrice(780);
		dto.setStock(17);
		dto.setRecommended(true);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(17);
		dto.setItemName("鞄F");
		dto.setManufacturer("(株)鞄");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("赤色");
		dto.setPrice(2500);
		dto.setStock(9);
		dto.setRecommended(true);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(18);
		dto.setItemName("鞄C");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("青色");
		dto.setPrice(1800);
		dto.setStock(20);
		dto.setRecommended(true);
		categoryData2.add(dto);

		dto = new ItemsDTO();
		dto.setItemId(19);
		dto.setItemName("鞄D");
		dto.setManufacturer("東京鞄店");
		dto.setCategory(new CategoriesDTO());
		dto.getCategory().setCategoryName("鞄");
		dto.setColor("緑色");
		dto.setPrice(1980);
		dto.setStock(2);
		dto.setRecommended(false);
		categoryData2.add(dto);
	}

	public List<ItemsDTO> getAllData(){
		return this.allData;
	}
	public List<ItemsDTO> getKeywordData(){
		return this.keywordData;
	}
	public List<ItemsDTO> getCategoryData1(){
		return this.categoryData1;
	}
	public List<ItemsDTO> getCategoryData2(){
		return this.categoryData2;
	}

}
