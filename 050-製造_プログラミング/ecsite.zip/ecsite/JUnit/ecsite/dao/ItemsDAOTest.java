package ecsite.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.bh.ecsite.dao.ItemsDAO;
import com.bh.ecsite.dto.CategoriesDTO;
import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;

class ItemsDAOTest {

	private static final String URL = "jdbc:postgresql://localhost/ecsite";
	private static final String USER = "ecsite";
	private static final String PASS = "ecsite";

	@Test
	void testNo1() {
		/*
		 * 全件検索を行い、以下の内容を確認する
		 * ・要素数
		 * ・1件目のデータ
		 * ・2件目のデータ
		 */
		List<ItemsDTO> testList = new ArrayList<>();
		ItemsDTO itemDto1 = new ItemsDTO();
		CategoriesDTO categoryDto1 = new CategoriesDTO();

		itemDto1.setItemId(1);
		itemDto1.setItemName("麦わら帽子");
		itemDto1.setManufacturer("日本帽子製造");
		itemDto1.setColor("黄色");
		itemDto1.setPrice(4980);
		itemDto1.setStock(12);
		itemDto1.setRecommended(false);

		categoryDto1.setCategoryId(1);
		categoryDto1.setCategoryName("帽子");

		itemDto1.setCategory(categoryDto1);

		ItemsDTO itemDto2 = new ItemsDTO();
		CategoriesDTO categoryDto2 = new CategoriesDTO();

		itemDto2.setItemId(2);
		itemDto2.setItemName("ストローハット");
		itemDto2.setManufacturer("(株)ストローハットジャパン");
		itemDto2.setColor("茶色");
		itemDto2.setPrice(3480);
		itemDto2.setStock(15);
		itemDto2.setRecommended(true);

		categoryDto2.setCategoryId(1);
		categoryDto2.setCategoryName("帽子");

		itemDto2.setCategory(categoryDto2);

		IItemsDAO<ItemsDTO> dao = new ItemsDAO();

		List<ItemsDTO> itemList = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
			itemList = dao.findAll(con);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(16, itemList.size());

		for (int i = 0; i < testList.size(); i++) {
			assertEquals(testList.get(i).getItemId(), itemList.get(i).getItemId());
			assertEquals(testList.get(i).getItemName(), itemList.get(i).getItemName());
			assertEquals(testList.get(i).getManufacturer(), itemList.get(i).getManufacturer());
			assertEquals(testList.get(i).getCategory().getCategoryName(),
					itemList.get(i).getCategory().getCategoryName());
			assertEquals(testList.get(i).getColor(), itemList.get(i).getColor());
			assertEquals(testList.get(i).getPrice(), itemList.get(i).getPrice());
			assertEquals(testList.get(i).getStock(), itemList.get(i).getStock());
			assertEquals(testList.get(i).isRecommended(), itemList.get(i).isRecommended());
		}
	}

	@Test
	void testNo2() {
		/*
		 * 全件検索を行い、在庫数が0の商品が取得されていないことを確認
		 */
		DAOTestData testdata = new DAOTestData();
		List<ItemsDTO> testList = testdata.getAllData();

		IItemsDAO<ItemsDTO> dao = new ItemsDAO();
		List<ItemsDTO> itemList = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
			itemList = dao.findAll(con);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		for (int i = 0; i < testList.size(); i++) {
			assertEquals(testList.get(i).getItemId(), itemList.get(i).getItemId());
			assertEquals(testList.get(i).getItemName(), itemList.get(i).getItemName());
			assertEquals(testList.get(i).getManufacturer(), itemList.get(i).getManufacturer());
			assertEquals(testList.get(i).getCategory().getCategoryName(),
					itemList.get(i).getCategory().getCategoryName());
			assertEquals(testList.get(i).getColor(), itemList.get(i).getColor());
			assertEquals(testList.get(i).getPrice(), itemList.get(i).getPrice());
			assertEquals(testList.get(i).getStock(), itemList.get(i).getStock());
			assertEquals(testList.get(i).isRecommended(), itemList.get(i).isRecommended());
		}
	}

	@Test
	void testNo3() {
		/*
		 * 0データ検索　どうやってやる？　デバッグ実行？？？
		 */
		IItemsDAO<ItemsDTO> dao = new ItemsDAO();
		List<ItemsDTO> itemList = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
			itemList = dao.findAll(con);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(0, itemList.size());
	}

	@Test
	void testNo4() {
		/*
		 * キーワード検索　1件検索を行い、以下の内容を確認
		 * ・要素数
		 * ・データの内容
		 */
		IItemsDAO<ItemsDTO> dao = new ItemsDAO();
		List<ItemsDTO> itemList = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {
			itemList = dao.findByKeyword(con,"野球帽");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		assertEquals(1, itemList.size());

		assertEquals(5, itemList.get(0).getItemId());
		assertEquals("野球帽", itemList.get(0).getItemName());
		assertEquals("日本帽子製造", itemList.get(0).getManufacturer());
		assertEquals("帽子", itemList.get(0).getCategory().getCategoryName());
		assertEquals("緑色", itemList.get(0).getColor());
		assertEquals(2500, itemList.get(0).getPrice());
		assertEquals(17, itemList.get(0).getStock());
		assertEquals(true, itemList.get(0).isRecommended());
	}
}
