package com.bh.ecsite.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bh.ecsite.dto.CategoriesDTO;
import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;

/**
 *
 * @author tk.okamoto
 *
 * DBのデータに操作を行うDAOの具象クラス<br />
 *
 * @param sql 実行用SQLを格納
 */
public class ItemsDAO implements IItemsDAO<ItemsDTO> {

	private String sql;

	/**
	 * 全件検索<br />
	 * <br />
	 * 戻り値：検索結果のリスト(itemList) <br />
	 * 例外：SQLException <br />
	 */
	@Override
	public List<ItemsDTO> findAll(Connection con) throws SQLException {

		sql = "select item_id, item_name, manufacturer, "
				+ "i.category_id, category_name, color, "
				+ "price, stock, recommended "
				+ "from items i left join categories c "
				+ "on i.category_id = c.category_id "
				+ "where stock > 0 "
				+ "order by item_id ";

		List<ItemsDTO> itemList = null;

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ResultSet rs = ps.executeQuery();

			itemList = new ArrayList<>();
			while (rs.next()) {
				ItemsDTO item = new ItemsDTO();
				CategoriesDTO category = new CategoriesDTO();

				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setManufacturer(rs.getString("manufacturer"));
				item.setColor(rs.getString("color"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setRecommended(rs.getBoolean("recommended"));

				category.setCategoryId(rs.getInt("category_id"));
				category.setCategoryName(rs.getString("category_name"));

				item.setCategory(category);

				//				item.getCategory().setCategoryName(categoryName);

				itemList.add(item);
			}
		} catch (SQLException e) {
			throw e;
		}

		return itemList;
	}

	/**
	 * キーワード検索<br />
	 * <br />
	 * 戻り値：検索結果のリスト(itemList) <br />
	 * 例外：SQLException <br />
	 */
	@Override
	public List<ItemsDTO> findByKeyword(Connection con, String keyword) throws SQLException {

		sql = "select item_id, item_name, manufacturer, "
				+ "i.category_id, category_name, color, "
				+ "price, stock, recommended "
				+ "from items i left join categories c "
				+ "on i.category_id = c.category_id "
				+ "where item_name like ? "
				+ "and stock > 0 "
				+ "order by item_id";

		List<ItemsDTO> itemList = null;

		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, "%" + keyword + "%");

			ResultSet rs = ps.executeQuery();

			itemList = new ArrayList<>();
			while (rs.next()) {
				ItemsDTO item = new ItemsDTO();
				CategoriesDTO category = new CategoriesDTO();

				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setManufacturer(rs.getString("manufacturer"));
				item.setColor(rs.getString("color"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setRecommended(rs.getBoolean("recommended"));

				category.setCategoryId(rs.getInt("category_id"));
				category.setCategoryName(rs.getString("category_name"));

				item.setCategory(category);

				itemList.add(item);
			}
		} catch (SQLException e) {
			throw e;
		}

		return itemList;
	}

	/**
	 * カテゴリー検索<br />
	 * <br />
	 * 戻り値：検索結果のリスト(itemList) <br />
	 * 例外：SQLException <br />
	 */
	@Override
	public List<ItemsDTO> findByCategoryId(Connection con, int categoryId) throws SQLException {

		sql = "select item_id, item_name, manufacturer, "
				+ "i.category_id, category_name, color, "
				+ "price, stock, recommended "
				+ "from items i left join categories c "
				+ "on i.category_id = c.category_id "
				+ "where i.category_id = ? "
				+ "and stock > 0 "
				+ "order by item_id ";

		List<ItemsDTO> itemList = null;

		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, categoryId);

			ResultSet rs = ps.executeQuery();

			itemList = new ArrayList<>();
			while (rs.next()) {
				ItemsDTO item = new ItemsDTO();
				CategoriesDTO category = new CategoriesDTO();

				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setManufacturer(rs.getString("manufacturer"));
				item.setColor(rs.getString("color"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setRecommended(rs.getBoolean("recommended"));

				category.setCategoryId(rs.getInt("category_id"));
				category.setCategoryName(rs.getString("category_name"));

				item.setCategory(category);

				itemList.add(item);
			}
		} catch (SQLException e) {
			throw e;
		}

		return itemList;
	}

	/**
	 * AND検索<br />
	 * <br />
	 * 戻り値：検索結果のリスト(itemList) <br />
	 * 例外：SQLException <br />
	 */
	@Override
	public List<ItemsDTO> findByBoth(Connection con, String keyword, int categoryId) throws SQLException {

		sql = "select item_id, item_name, manufacturer, "
				+ "i.category_id, category_name, color, "
				+ "price, stock, recommended "
				+ "from items i left join categories c "
				+ "on i.category_id = c.category_id "
				+ "where item_name like ? and i.category_id = ? "
				+ "and stock > 0 "
				+ "order by item_id ";

		List<ItemsDTO> itemList = null;

		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, "%" + keyword + "%");
			ps.setInt(2, categoryId);

			ResultSet rs = ps.executeQuery();

			itemList = new ArrayList<>();
			while (rs.next()) {
				ItemsDTO item = new ItemsDTO();
				CategoriesDTO category = new CategoriesDTO();

				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setManufacturer(rs.getString("manufacturer"));
				item.setColor(rs.getString("color"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setRecommended(rs.getBoolean("recommended"));

				category.setCategoryId(rs.getInt("category_id"));
				category.setCategoryName(rs.getString("category_name"));

				item.setCategory(category);

				itemList.add(item);
			}
		} catch (SQLException e) {
			throw e;
		}

		return itemList;
	}

	/**
	 * 商品IDでデータを取得する<br />
	 *
	 * 戻り値：ItemsDTO 商品データを1件返す<br />
	 * 例外：SQLException
	 */
	public ItemsDTO findByItemId(Connection con, int itemId) throws SQLException {

		sql = "select item_id, item_name, manufacturer, "
				+ "i.category_id, category_name, color, "
				+ "price, stock, recommended "
				+ "from items i left join categories c "
				+ "on i.category_id = c.category_id "
				+ "where item_id = ? "
				+ "and stock > 0 "
				+ "order by item_id ";

		ItemsDTO item = new ItemsDTO();

		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, itemId);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				CategoriesDTO category = new CategoriesDTO();

				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setManufacturer(rs.getString("manufacturer"));
				item.setColor(rs.getString("color"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setRecommended(rs.getBoolean("recommended"));

				category.setCategoryId(rs.getInt("category_id"));
				category.setCategoryName(rs.getString("category_name"));

				item.setCategory(category);
			}
		} catch (SQLException e) {
			throw e;
		}

		return item;
	}
}
