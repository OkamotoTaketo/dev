package com.bh.ecsite.interfaces;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface IItemsDAO<T> {
	List<T> findAll(Connection con) throws SQLException;
	List<T> findByKeyword(Connection con, String keyword) throws SQLException;
	List<T> findByCategoryId(Connection con , int categoryId) throws SQLException;
	List<T> findByBoth(Connection con, String keyword, int categoryId) throws SQLException;
	T findByItemId(Connection con, int itemId) throws SQLException ;
}
