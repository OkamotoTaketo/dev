package com.bh.ecsite.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class AbstractService {

	private static final String URL = "jdbc:postgresql://localhost/ecsite";
	private static final String USER = "ecsite";
	private static final String PASS = "ecsite";

	/**
	 * JDBCドライバの登録<br />
	 *
	 * @throws ClassNotFoundException
	 */
	public void registDriver() throws ClassNotFoundException {
		try {
			Class.forName("org.postgresql.Driver");
		}catch(ClassNotFoundException e) {
//			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * コネクションの生成<br />
	 *
	 * @return Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;

		try {
			con = DriverManager.getConnection(URL,USER,PASS);
		}catch(SQLException e) {
			throw e;
		}

		return con;
	}
}
