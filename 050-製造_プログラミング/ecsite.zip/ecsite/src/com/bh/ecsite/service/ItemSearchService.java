package com.bh.ecsite.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;

public class ItemSearchService extends AbstractService{

	private IItemsDAO<ItemsDTO> iDAO;

	public ItemSearchService(IItemsDAO<ItemsDTO> iDAO) {
//		依存性の注入
		this.iDAO = iDAO;
	}

	/**
	 * 商品検索のメソッド
	 *
	 *
	 * @param keyword  入力されたキーワード
	 * @param category 指定されたカテゴリー
	 * @return 検索結果のリスト
	 * @throws ClassNotFoundException システムエラー
	 * @throws SQLException           システムエラー
	 * @throws NumberFormatException  業務エラー
	 * @throws NullPointerException   業務エラー
	 */
	public List<ItemsDTO> itemSearch(String keyword, String category)
			throws ClassNotFoundException, SQLException, NumberFormatException, NullPointerException {

		registDriver();

		List<ItemsDTO> itemList = null;

		if(keyword == null || category == null) {
			throw new NullPointerException();
		}

		int categoryId = 0;
		try {
			categoryId = Integer.parseInt(category);
		}catch(NumberFormatException e) {
			throw e;
		}

		try (Connection con = getConnection()){

			if(keyword.equals("") && categoryId == 0) {
//			全件検索
				itemList = iDAO.findAll(con);
			}else if(!keyword.equals("") && categoryId == 0) {
//			キーワード検索
				itemList = iDAO.findByKeyword(con, keyword);
			}else if(keyword.equals("") && categoryId != 0) {
//			カテゴリー検索
				itemList = iDAO.findByCategoryId(con, categoryId);
			}else if(!keyword.equals("") && categoryId != 0) {
//			AND検索
				itemList = iDAO.findByBoth(con, keyword, categoryId);
			}

		}catch(SQLException e) {
			throw e;
		}

		return itemList;
	}
}
