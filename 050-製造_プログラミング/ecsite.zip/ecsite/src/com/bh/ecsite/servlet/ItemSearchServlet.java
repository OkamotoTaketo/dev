package com.bh.ecsite.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bh.ecsite.dao.ItemsDAO;
import com.bh.ecsite.dto.ItemsDTO;
import com.bh.ecsite.interfaces.IItemsDAO;
import com.bh.ecsite.service.ItemSearchService;
import com.bh.ecsite.util.PageUtil;

/**
 * Servlet implementation class ItemSearchServlet
 */
@WebServlet("/ItemSearchServlet")
public class ItemSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IItemsDAO<ItemsDTO> iDAO = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ItemSearchServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see GenericServlet#init()
	 */
	public void init() {
		//    	具象DAOをインスタンス化してIF型に格納
		iDAO = new ItemsDAO();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//		doGet(request, response);

		String path = "/WEB-INF/search_result.jsp";

		String keyword = request.getParameter("keyword");
		String category = request.getParameter("categoryId");

		if (keyword == null && category == null) {
			keyword = (String) request.getSession().getAttribute("keyword");
			category = (String) request.getSession().getAttribute("categoryId");
		}

		ItemSearchService service = new ItemSearchService(iDAO);

		List<ItemsDTO> itemList = null;

		try {
			itemList = service.itemSearch(keyword, category);


		} catch (ClassNotFoundException | SQLException e) {
			System.err.println(e.getMessage());
			path = "/WEB-INF/main.jsp";
			request.setAttribute("message", "エラーが発生しました。再度お試しください。");
			request.getRequestDispatcher(path).forward(request, response);
			return;

//		} catch (SQLException e) {
//			System.err.println("SQL");
//			System.err.println(e.getMessage());
//			path = "/WEB-INF/main.jsp";
//			request.setAttribute("message", "エラーが発生しました。再度お試しください。");
//			request.getRequestDispatcher(path).forward(request, response);
//			return;

		} catch (NullPointerException | NumberFormatException e) {
			System.err.println(e.getMessage());
			path = "/WEB-INF/main.jsp";
			request.setAttribute("message", "不正な操作を検出しました。やり直してください。");
			request.getRequestDispatcher(path).forward(request, response);
			return;

//		} catch (NumberFormatException e) {
//			System.err.println("Number");
//			path = "/WEB-INF/main.jsp";
//			request.setAttribute("message", "不正な操作を検出しました。やり直してください。");
//			request.getRequestDispatcher(path).forward(request, response);
//			return;

		}

//		検索情報を文章にまとめる
		String message = "";
		if (!keyword.equals("")) {
			message += "キーワード \"" + keyword + "\" ";

			if (category.equals("0")) {
				message += "カテゴリ \"すべて\" ";
			}
			if (category.equals("1")) {
				message += "カテゴリ \"帽子\" ";
			}
			if (category.equals("2")) {
				message += "カテゴリ \"鞄\" ";
			}
		} else {
			if (category.equals("1")) {
				message += "カテゴリ \"帽子\" ";
			}
			if (category.equals("2")) {
				message += "カテゴリ \"鞄\" ";
			}
		}
		if (!message.equals("")) {
			message += "の検索結果";
		}

		//		メインページからの遷移かを確認
		String first = request.getParameter("first");
		boolean judge;
		if (first == null) {
			judge = false;
		} else {
			judge = Boolean.parseBoolean(first);
		}
		if (judge) {
			//			メインページからの場合、ページングは最初のページを指定
			PageUtil.setCurrentPage(1);
		}
		itemList = PageUtil.getPagingList(itemList);
		request.getSession().setAttribute("keyword", keyword);
		request.getSession().setAttribute("categoryId", category);

		//アトリビュート設定
		request.setAttribute("itemList", itemList);
		request.setAttribute("message", message);
		request.setAttribute("currentPage", PageUtil.getCurrentPage());
		request.setAttribute("maxPage", PageUtil.getMaxPage());
		request.setAttribute("before", PageUtil.prevPageDisplay());
		request.setAttribute("next", PageUtil.nextPageDisplay());

		request.getRequestDispatcher(path).forward(request, response);
		return;
	}

}
