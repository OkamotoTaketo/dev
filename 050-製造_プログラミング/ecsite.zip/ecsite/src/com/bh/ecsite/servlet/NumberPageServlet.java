package com.bh.ecsite.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bh.ecsite.util.PageUtil;

/**
 * Servlet implementation class NumberPageServlet
 */
@WebServlet("/NumberPageServlet")
public class NumberPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public NumberPageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		String path;

		String page = request.getParameter("page");

		int pageNumber=1;
		try {
			pageNumber = Integer.parseInt(page);
		}catch(NumberFormatException e) {
			path = "/WEB-INF/main/index.jsp";
			request.setAttribute("message", "不正な操作を検出しました。");
			request.getRequestDispatcher(path).forward(request, response);
			return;
		}

		if(pageNumber <= 0 || pageNumber > PageUtil.getMaxPage()) {
			path = "/404.jsp";
			request.setAttribute("message", "不正な操作を検出しました。");
			request.getRequestDispatcher(path).forward(request, response);
			return;
		}


		PageUtil.setCurrentPage(pageNumber);

		path = "/ecsite/ItemSearchServlet";
		System.out.println("next redirect");
		response.sendRedirect(path);
		return;
	}

}
