package com.bh.ecsite.util;

import java.util.ArrayList;
import java.util.List;

import com.bh.ecsite.dto.ItemsDTO;

public class PageUtil {
	/**
	 * 1ページ中に表示される最大件数
	 */
	public static final int OUTPUT_NUM = 10;

	/**
	 * 全レコードの件数
	 */
	private static long recordNum;

	/**
	 * 現在のページ
	 */
	private static int currentPage = 1;

	/**
	 * 全レコードの件数から算出されるページ数（recordNum/outputNum）
	 */
	private static int maxPage;

	public static void config(Long recordNum) {
		PageUtil.recordNum = recordNum;
		PageUtil.maxPage = (int)(PageUtil.recordNum / OUTPUT_NUM);

		if (PageUtil.recordNum % OUTPUT_NUM != 0 || PageUtil.recordNum == 0) {
			PageUtil.maxPage++;
		}
	}

	public static void setCurrentPage(int currentPage) {
		PageUtil.currentPage = currentPage;
	}
	public static int getCurrentPage() {
		return PageUtil.currentPage;
	}

	public static int getMaxPage() {
		return PageUtil.maxPage;
	}

	/**
	 * 前ページボタンを表示するか
	 * @return
	 */
	public static boolean prevPageDisplay() {
		return currentPage > 1;
	}

	/**
	 * 次ページボタンを表示するか
	 * @return
	 */
	public static boolean nextPageDisplay() {
		return currentPage < maxPage;
	}

	/**
	 * 最初のページへ
	 */
	public static void topPage() {
		currentPage = 1;
	}

	/**
	 * 最後のページへ
	 */
	public static void lastPage() {
		currentPage = (int) maxPage;
	}

	/**
	 * 前のページへ
	 */
	public static void prevPage() {
		if (prevPageDisplay()) {
			currentPage--;
		}
	}

	/**
	 * 次のページへ
	 */
	public static void nextPage() {
		if (nextPageDisplay()) {
			currentPage++;
		}
	}

	/**
	 * 何番目のレコードから表示するか
	 * @return
	 */
	public static Integer offset() {
		return (currentPage - 1) * OUTPUT_NUM;
	}


//	ページングに合わせたリストの内容を返す
	public static List<ItemsDTO> getPagingList(List<ItemsDTO> list) {
		config((long) list.size());
		List<ItemsDTO> returnList = new ArrayList<>();
		int offset = offset();
		int num = OUTPUT_NUM;

		// recordNum % OUTPUT_NUM != 0の場合リストの外を参照する
//		上記原因:繰り返し条件がANDだったせい
//		どちらかの条件がtrueの時点で編集終了になる
		for (int i = offset; i < offset + num && i < recordNum; i++) {
			returnList.add(list.get(i));
		}
		return returnList;
	}
}
